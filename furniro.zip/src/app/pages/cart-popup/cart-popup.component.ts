import { Component } from '@angular/core';

@Component({
  selector: 'app-cart-popup',
  standalone: true,
  imports: [],
  templateUrl: './cart-popup.component.html',
  styleUrl: './cart-popup.component.scss'
})
export class CartPopupComponent {

}
